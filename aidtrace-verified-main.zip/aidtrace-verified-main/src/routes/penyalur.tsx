import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { sha256 } from "js-sha256";
import { Ban, CheckCircle2, Clock, Files, Plus, Send, ThumbsUp, Upload } from "lucide-react";
import { toast } from "sonner";
import { DashboardShell, RoleGate } from "@/components/bt/Layout";
import { Badge, Button, Card, EmptyState, LoadingState, Modal, Mono, SearchInput, StatCard, Table, type Column } from "@/components/bt/primitives";
import { type AidRecord, PROGRAMS, STATUSES, type Status, computeHash, currentStatus, formatIDR, formatTs, lastEntry, nextAction, randomHex } from "@/lib/bt-data";
import { usePageLoad, useStore } from "@/lib/bt-store";

export const Route = createFileRoute("/penyalur")({
  head: () => ({
    meta: [
      { title: "Dasbor Penyalur — BantuanTrace" },
      { name: "description", content: "Kelola dan catat status penyaluran bantuan pendidikan." },
      { property: "og:title", content: "Dasbor Penyalur — BantuanTrace" },
      { property: "og:description", content: "Kelola penyaluran bantuan dan catat bukti on-chain." },
    ],
  }),
  component: () => (
    <RoleGate role="penyalur">
      <DashboardShell role="penyalur" title="Dasbor Penyalur">
        <DistributorPage />
      </DashboardShell>
    </RoleGate>
  ),
});

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
const ACTION_LABEL: Partial<Record<Status, { label: string; variant: "success" | "warning" | "danger"; icon: typeof ThumbsUp }>> = {
  DISETUJUI: { label: "Setujui", variant: "success", icon: ThumbsUp },
  DICAIRKAN: { label: "Cairkan", variant: "warning", icon: Send },
  DIBATALKAN: { label: "Batalkan", variant: "danger", icon: Ban },
};

function DistributorPage() {
  const { records, updateStatus } = useStore();
  const loading = usePageLoad();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<Status | "ALL">("ALL");
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState<string | null>(null);

  const stats = useMemo(() => {
    const c = { total: records.length, received: 0, progress: 0, cancelled: 0 };
    records.forEach((r) => {
      const s = currentStatus(r);
      if (s === "DITERIMA") c.received++;
      else if (s === "DIBATALKAN") c.cancelled++;
      else c.progress++;
    });
    return c;
  }, [records]);

  const monthly = useMemo(() => {
    const counts = new Map<string, number>();
    records.forEach((r) => {
      const d = new Date(r.timeline[0]!.ts);
      const k = `${d.getUTCFullYear()}-${String(d.getUTCMonth()).padStart(2, "0")}`;
      counts.set(k, (counts.get(k) ?? 0) + 1);
    });
    return [...counts.entries()].sort().slice(-8).map(([k, v]) => ({ label: MONTHS[parseInt(k.slice(5), 10)] ?? "", value: v }));
  }, [records]);
  const maxM = Math.max(1, ...monthly.map((m) => m.value));

  const filtered = records.filter((r) => {
    const s = q.trim().toLowerCase();
    return (status === "ALL" || currentStatus(r) === status) && (!s || r.code.toLowerCase().includes(s) || r.alias.toLowerCase().includes(s) || r.program.toLowerCase().includes(s));
  });

  const act = async (code: string, s: Status) => {
    setPending(`${code}:${s}`);
    try {
      await updateStatus(code, s);
      toast.success(`${code} → ${s}`, { description: "Recorded to Solana devnet (simulated)" });
    } catch {
      toast.error("Gagal mencatat ke jaringan. Coba lagi.");
    } finally {
      setPending(null);
    }
  };

  const columns: Column<AidRecord>[] = [
    { header: "Kode", cell: (r) => <span className="font-mono font-semibold">{r.code}</span> },
    { header: "Penerima (alias)", cell: (r) => <div><p className="font-medium">{r.alias}</p><p className="font-mono text-xs text-muted-foreground">{r.recipientCode}</p></div> },
    { header: "Program", cell: (r) => <div><p>{r.program}</p><p className="text-xs text-muted-foreground">{formatIDR(r.amount)}</p></div> },
    { header: "Status", cell: (r) => <div><Badge status={currentStatus(r)} /><p className="mt-1 text-[11px] text-muted-foreground">{formatTs(lastEntry(r).ts)}</p></div> },
    {
      header: "Aksi",
      cell: (r) => {
        const acts = nextAction(currentStatus(r));
        if (!acts.length) return <span className="text-xs text-muted-foreground">{currentStatus(r) === "DICAIRKAN" ? "" : "Selesai"}</span>;
        return (
          <div className="flex flex-wrap gap-1.5">
            {acts.map((s) => {
              const a = ACTION_LABEL[s]!;
              return (
                <Button key={s} size="sm" variant={a.variant} loading={pending === `${r.code}:${s}`} disabled={!!pending} onClick={() => act(r.code, s)}>
                  <a.icon className="h-3.5 w-3.5" /> {a.label}
                </Button>
              );
            })}
          </div>
        );
      },
    },
  ];

  return (
    <>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Total Penyaluran" value={stats.total} icon={<Files className="h-4 w-4" />} tone="info" />
        <StatCard label="Diterima" value={stats.received} icon={<CheckCircle2 className="h-4 w-4" />} tone="success" />
        <StatCard label="Dalam Proses" value={stats.progress} icon={<Clock className="h-4 w-4" />} tone="warning" />
        <StatCard label="Dibatalkan" value={stats.cancelled} icon={<Ban className="h-4 w-4" />} tone="danger" />
      </div>

      <Card>
        <h2 className="font-semibold">Tren penyaluran bulanan</h2>
        {loading ? <div className="mt-4 h-40 animate-pulse rounded-xl bg-muted" /> : monthly.length === 0 ? <div className="mt-4"><EmptyState title="Belum ada data" /></div> : (
          <div className="mt-4 flex h-44 items-end gap-2 sm:gap-4">
            {monthly.map((m) => (
              <div key={m.label} className="flex flex-1 flex-col items-center gap-1">
                <span className="font-mono text-xs text-muted-foreground">{m.value}</span>
                <div className="w-full max-w-12 rounded-t-lg bg-gradient-primary" style={{ height: `${(m.value / maxM) * 120}px` }} />
                <span className="text-xs text-muted-foreground">{m.label}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card>
        <div className="mb-4 flex flex-col gap-2 sm:flex-row sm:items-center">
          <h2 className="flex-1 font-semibold">Master Penyaluran</h2>
          <Button onClick={() => setOpen(true)}><Plus className="h-4 w-4" /> Tambah Penyaluran</Button>
        </div>
        <div className="mb-4 flex flex-col gap-2 sm:flex-row">
          <SearchInput value={q} onChange={setQ} placeholder="Cari kode, alias, atau program" className="flex-1" />
          <select value={status} onChange={(e) => setStatus(e.target.value as Status | "ALL")} className="h-10 rounded-xl border bg-surface px-3 text-sm">
            <option value="ALL">Semua status</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        {loading ? <LoadingState /> : <Table columns={columns} rows={filtered} rowKey={(r) => r.code} empty={<EmptyState title="Tidak ada penyaluran" desc="Ubah filter atau tambah penyaluran baru." />} />}
      </Card>

      {open && <AddModal onClose={() => setOpen(false)} />}
    </>
  );
}

const ALIAS_RE = /^[\p{L}\p{N} .,'()-]{3,60}$/u;
const RCP_RE = /^RCP-\d{3}$/;
const ALLOWED = ["application/pdf", "image/png", "image/jpeg"];

function AddModal({ onClose }: { onClose: () => void }) {
  const { nextCode, createRecord } = useStore();
  const [salt] = useState(() => randomHex(16));
  const [code] = useState(() => nextCode());
  const [alias, setAlias] = useState("");
  const [rcp, setRcp] = useState("");
  const [program, setProgram] = useState<string>(PROGRAMS[0]!);
  const [amount, setAmount] = useState("");
  const [file, setFile] = useState<{ name: string; hash: string } | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);

  const amt = Number(amount);
  const preview = file && alias && rcp && amt ? computeHash({ code, alias: alias.trim(), recipientCode: rcp, program, amount: amt, docName: file.name, docHash: file.hash, salt }) : null;

  const onFile = async (f?: File) => {
    if (!f) return;
    if (!ALLOWED.includes(f.type)) return setErrors((e) => ({ ...e, file: "Hanya PDF, PNG, atau JPG." }));
    if (f.size > 2 * 1024 * 1024) return setErrors((e) => ({ ...e, file: "Maksimal 2 MB." }));
    const buf = await f.arrayBuffer();
    setFile({ name: f.name.replace(/[^\w.\- ]/g, "_").slice(0, 80), hash: sha256(buf) });
    setErrors((e) => ({ ...e, file: "" }));
  };

  const submit = async () => {
    const e: Record<string, string> = {};
    if (!ALIAS_RE.test(alias.trim())) e["alias"] = "3–60 karakter, huruf/angka saja.";
    if (!RCP_RE.test(rcp)) e["rcp"] = "Format RCP-001.";
    if (!Number.isFinite(amt) || amt < 10_000 || amt > 100_000_000) e["amount"] = "Rp10.000 – Rp100.000.000.";
    if (!file) e["file"] = "Unggah dokumen dummy.";
    setErrors(e);
    if (Object.keys(e).length || !file) return;
    setSaving(true);
    try {
      const rec = await createRecord({ alias: alias.trim(), recipientCode: rcp, program, amount: amt, docName: file.name, docHash: file.hash, salt });
      toast.success(`${rec.code} dibuat`, { description: "Recorded to Solana devnet (simulated)" });
      onClose();
    } catch {
      toast.error("Gagal menyimpan penyaluran.");
      setSaving(false);
    }
  };

  const field = "h-10 w-full rounded-xl border bg-surface px-3 text-sm outline-none focus:ring-2 focus:ring-ring";

  return (
    <Modal open onClose={onClose} title="Tambah Penyaluran Baru" footer={<><Button variant="outline" onClick={onClose}>Batal</Button><Button onClick={submit} loading={saving}>Simpan & Catat On-Chain</Button></>}>
      <div className="space-y-3 text-sm">
        <div className="flex items-center justify-between rounded-xl bg-surface p-3"><span className="text-muted-foreground">Kode otomatis</span><span className="font-mono font-semibold">{code}</span></div>
        <L label="Alias penerima (dummy)" err={errors["alias"]}><input className={field} value={alias} maxLength={60} onChange={(e) => setAlias(e.target.value)} placeholder="Penerima Dummy" /></L>
        <L label="Kode penerima" err={errors["rcp"]}><input className={`${field} font-mono`} value={rcp} maxLength={7} onChange={(e) => setRcp(e.target.value.toUpperCase())} placeholder="RCP-001" /></L>
        <L label="Program"><select className={field} value={program} onChange={(e) => setProgram(e.target.value)}>{PROGRAMS.map((p) => <option key={p}>{p}</option>)}</select></L>
        <L label="Nominal (Rp, off-chain)" err={errors["amount"]}><input className={field} type="number" inputMode="numeric" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="1500000" /></L>
        <L label="Dokumen (dummy)" err={errors["file"]}>
          <label className="flex cursor-pointer items-center gap-2 rounded-xl border border-dashed bg-surface p-3 hover:bg-accent">
            <Upload className="h-4 w-4 text-muted-foreground" />
            <span className="truncate">{file ? file.name : "Pilih PDF/PNG/JPG (maks 2 MB)"}</span>
            <input type="file" accept=".pdf,.png,.jpg,.jpeg" className="hidden" onChange={(e) => onFile(e.target.files?.[0])} />
          </label>
        </L>
        <div className="rounded-xl bg-surface p-3">
          <p className="text-xs text-muted-foreground">Salt acak</p><Mono>{salt}</Mono>
          <p className="mt-2 text-xs text-muted-foreground">Hash SHA-256 (otomatis)</p><Mono className={preview ? "text-primary" : "text-muted-foreground"}>{preview ?? "Lengkapi form untuk membuat hash"}</Mono>
        </div>
      </div>
    </Modal>
  );
}

function L({ label, err, children }: { label: string; err?: string | undefined; children: React.ReactNode }) {
  return (
    <div>
      <p className="mb-1 text-xs font-medium text-muted-foreground">{label}</p>
      {children}
      {err && <p className="mt-1 text-xs text-danger">{err}</p>}
    </div>
  );
}
