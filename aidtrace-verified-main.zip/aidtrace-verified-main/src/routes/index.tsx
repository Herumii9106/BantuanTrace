import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ArrowRight, CheckCircle2, FileLock2, Fingerprint, Link2, Lock, PenLine, ReceiptText, ScanSearch, ShieldCheck } from "lucide-react";
import { PublicLayout } from "@/components/bt/Layout";
import { Button, Card, SearchInput } from "@/components/bt/primitives";
import { CODE_RE, HASH_RE } from "@/lib/bt-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BantuanTrace — Bukti penyaluran bantuan pendidikan" },
      { name: "description", content: "Periksa sendiri bukti penyaluran bantuan pendidikan yang tercatat on-chain, tanpa membuka data pribadi." },
      { property: "og:title", content: "BantuanTrace — Bukti penyaluran bantuan pendidikan" },
      { property: "og:description", content: "Periksa sendiri bukti penyaluran bantuan pendidikan yang tercatat on-chain." },
    ],
  }),
  component: Landing,
});

const VALUES = [
  { icon: Lock, title: "Tidak bisa diubah diam-diam", desc: "Setiap perubahan status tercatat dengan hash dan tanda waktu. Satu karakter berubah, verifikasi gagal." },
  { icon: FileLock2, title: "Data pribadi tetap privat", desc: "Nama, NIK/NIM, dokumen, dan nominal tetap off-chain. Publik hanya melihat kode anonim dan hash." },
  { icon: ReceiptText, title: "Bukti terima untuk penerima", desc: "Penerima menandatangani pesan konfirmasi dan mendapat bukti terima ber-QR." },
];

const STEPS = [
  { icon: PenLine, title: "Catat", desc: "Penyalur mencatat bantuan" },
  { icon: Fingerprint, title: "Hash", desc: "SHA-256 + salt acak" },
  { icon: Link2, title: "Catat On-Chain", desc: "Bukti ke Solana devnet" },
  { icon: CheckCircle2, title: "Konfirmasi Terima", desc: "Penerima tanda tangan pesan" },
  { icon: ScanSearch, title: "Verifikasi", desc: "Siapa pun bisa memeriksa" },
];

function Landing() {
  const [q, setQ] = useState("");
  const [err, setErr] = useState("");
  const navigate = useNavigate();
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const v = q.trim();
    if (!CODE_RE.test(v) && !HASH_RE.test(v)) return setErr("Masukkan kode (contoh BT-001) atau hash SHA-256 64 karakter.");
    navigate({ to: "/verifikasi", search: { q: v } });
  };

  return (
    <PublicLayout>
      <section className="relative overflow-hidden">
        <div className="grid-bg absolute inset-0 opacity-40 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
        <div className="bg-hero absolute inset-0" />
        <div className="relative mx-auto max-w-4xl px-4 pb-16 pt-16 text-center sm:pt-24">
          <span className="inline-flex items-center gap-2 rounded-full border bg-surface px-3 py-1 font-mono text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Solana devnet · simulasi
          </span>
          <h1 className="mt-6 text-4xl font-bold leading-[1.05] sm:text-6xl">
            Bukti penyaluran bantuan yang <span className="bg-gradient-primary bg-clip-text text-transparent">bisa kamu periksa sendiri</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-muted-foreground">
            Setiap tahap bantuan pendidikan tercatat sebagai jejak status yang tidak bisa diubah diam-diam — tanpa membuka data pribadi siapa pun.
          </p>
          <form onSubmit={submit} className="mx-auto mt-8 flex max-w-xl flex-col gap-2 rounded-2xl border bg-card p-2 shadow-elegant sm:flex-row">
            <SearchInput value={q} onChange={(v) => { setQ(v); setErr(""); }} placeholder="Kode (BT-001) atau hash dokumen" className="flex-1" />
            <Button type="submit"><ShieldCheck className="h-4 w-4" /> Verifikasi</Button>
          </form>
          {err && <p className="mt-2 text-sm text-danger">{err}</p>}
          <p className="mt-3 text-xs text-muted-foreground">Coba: <button className="font-mono underline" onClick={() => navigate({ to: "/verifikasi", search: { q: "BT-001" } })}>BT-001</button></p>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-4 py-12 md:grid-cols-3">
        {VALUES.map((v) => (
          <Card key={v.title}>
            <v.icon className="h-6 w-6 text-primary" />
            <h3 className="mt-4 text-lg font-semibold">{v.title}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{v.desc}</p>
          </Card>
        ))}
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-center text-3xl font-bold">Cara kerja</h2>
        <ol className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {STEPS.map((s, i) => (
            <li key={s.title} className="relative rounded-2xl border bg-surface p-4">
              <span className="font-mono text-xs text-muted-foreground">0{i + 1}</span>
              <s.icon className="mt-2 h-5 w-5 text-primary" />
              <p className="mt-3 font-semibold">{s.title}</p>
              <p className="text-xs text-muted-foreground">{s.desc}</p>
              {i < STEPS.length - 1 && <ArrowRight className="absolute -right-3 top-1/2 z-10 hidden h-5 w-5 -translate-y-1/2 text-muted-foreground lg:block" />}
            </li>
          ))}
        </ol>
      </section>
    </PublicLayout>
  );
}
