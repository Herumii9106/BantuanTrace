import { useMemo, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";
import { DashboardShell, RoleGate } from "@/components/bt/Layout";
import { Badge, Button, Card, EmptyState, LoadingState, Mono, SearchInput, Table, type Column } from "@/components/bt/primitives";
import { type AidRecord, STATUSES, type Status, currentStatus, explorerUrl, formatTs, lastEntry } from "@/lib/bt-data";
import { usePageLoad, useStore } from "@/lib/bt-store";

export const Route = createFileRoute("/auditor")({
  head: () => ({
    meta: [
      { title: "Daftar Catatan Auditor — BantuanTrace" },
      { name: "description", content: "Daftar anonim seluruh catatan penyaluran bantuan untuk auditor." },
      { property: "og:title", content: "Daftar Catatan Auditor — BantuanTrace" },
      { property: "og:description", content: "Tabel anonim penyaluran bantuan dengan hash dan tautan explorer." },
    ],
  }),
  component: () => (
    <RoleGate role="auditor">
      <DashboardShell role="auditor" title="Daftar Catatan">
        <AuditorPage />
      </DashboardShell>
    </RoleGate>
  ),
});

const PER_PAGE = 8;

function AuditorPage() {
  const { records } = useStore();
  const loading = usePageLoad();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<Status | "ALL">("ALL");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return records.filter((r) => (status === "ALL" || currentStatus(r) === status) && (!s || r.code.toLowerCase().includes(s) || r.onchainHash.includes(s)));
  }, [records, q, status]);
  const pages = Math.max(1, Math.ceil(filtered.length / PER_PAGE));
  const cur = Math.min(page, pages);
  const rows = filtered.slice((cur - 1) * PER_PAGE, cur * PER_PAGE);

  const columns: Column<AidRecord>[] = [
    { header: "Kode", cell: (r) => <Link to="/verifikasi" search={{ q: r.code }} className="font-mono font-semibold text-primary hover:underline">{r.code}</Link> },
    { header: "Status", cell: (r) => <Badge status={currentStatus(r)} /> },
    { header: "Waktu", cell: (r) => <span className="whitespace-nowrap text-muted-foreground">{formatTs(lastEntry(r).ts)}</span> },
    { header: "Hash", cell: (r) => <Mono title-hash={r.onchainHash}>{r.onchainHash.slice(0, 10)}…{r.onchainHash.slice(-6)}</Mono> },
    {
      header: "Explorer",
      cell: (r) => (
        <a href={explorerUrl(lastEntry(r).tx)} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
          Lihat <ExternalLink className="h-3 w-3" />
        </a>
      ),
    },
  ];

  return (
    <Card>
      <div className="mb-4 flex flex-col gap-2 sm:flex-row">
        <SearchInput value={q} onChange={(v) => { setQ(v); setPage(1); }} placeholder="Cari kode atau hash" className="flex-1" />
        <select value={status} onChange={(e) => { setStatus(e.target.value as Status | "ALL"); setPage(1); }} className="h-10 rounded-xl border bg-surface px-3 text-sm">
          <option value="ALL">Semua status</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>
      {loading ? (
        <LoadingState />
      ) : (
        <>
          <Table columns={columns} rows={rows} rowKey={(r) => r.code} empty={<EmptyState title="Tidak ada catatan" desc="Ubah kata kunci atau filter status." />} />
          {filtered.length > 0 && (
            <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
              <span>{filtered.length} catatan · halaman {cur}/{pages}</span>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" disabled={cur <= 1} onClick={() => setPage(cur - 1)} aria-label="Sebelumnya"><ChevronLeft className="h-4 w-4" /></Button>
                <Button size="sm" variant="outline" disabled={cur >= pages} onClick={() => setPage(cur + 1)} aria-label="Berikutnya"><ChevronRight className="h-4 w-4" /></Button>
              </div>
            </div>
          )}
        </>
      )}
    </Card>
  );
}
