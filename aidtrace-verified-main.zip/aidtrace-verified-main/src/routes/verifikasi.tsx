import { useCallback, useEffect, useRef, useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Blocks, CheckCircle2, ExternalLink, Fingerprint, Loader2, ShieldAlert, ShieldCheck, XCircle } from "lucide-react";
import { PublicLayout } from "@/components/bt/Layout";
import { Badge, Button, Card, ErrorState, Mono, SearchInput } from "@/components/bt/primitives";
import { StatusTimeline } from "@/components/bt/StatusTimeline";
import { type AidRecord, CODE_RE, HASH_RE, computeHash, currentStatus, explorerUrl, lastEntry, shortAddr, tamperRecord } from "@/lib/bt-data";
import { useStore } from "@/lib/bt-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/verifikasi")({
  validateSearch: (s: Record<string, unknown>): { q?: string | undefined } => ({
    q: typeof s["q"] === "string" ? s["q"].slice(0, 80) : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Verifikasi Penyaluran — BantuanTrace" },
      { name: "description", content: "Cari kode anonim atau hash dokumen untuk memverifikasi penyaluran bantuan on-chain." },
      { property: "og:title", content: "Verifikasi Penyaluran — BantuanTrace" },
      { property: "og:description", content: "Verifikasi status bantuan pendidikan dengan kode anonim atau hash SHA-256." },
    ],
  }),
  component: VerifyPage,
});

const SCAN_MSGS = ["Menghubungkan ke Solana devnet…", "Reading On-Chain Hash…", "Mencocokkan blok & tanda tangan…"];

function VerifyPage() {
  const { q } = Route.useSearch();
  const navigate = useNavigate();
  const { findRecord } = useStore();
  const [input, setInput] = useState(q ?? "");
  const [phase, setPhase] = useState<"idle" | "scanning" | "done" | "error">("idle");
  const [error, setError] = useState("");
  const [scanIdx, setScanIdx] = useState(0);
  const [record, setRecord] = useState<AidRecord | null>(null);
  const [tampered, setTampered] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [result, setResult] = useState<{ ok: boolean; recomputed: string } | null>(null);
  const timers = useRef<number[]>([]);

  const clear = () => { timers.current.forEach(clearTimeout); timers.current = []; };

  const runVerify = useCallback((rec: AidRecord, tamper: boolean, ms = 900) => {
    setVerifying(true);
    const t = window.setTimeout(() => {
      const recomputed = computeHash(tamper ? tamperRecord(rec) : rec);
      setResult({ ok: recomputed === rec.onchainHash, recomputed });
      setVerifying(false);
    }, ms);
    timers.current.push(t);
  }, []);

  const lookup = useCallback((raw: string) => {
    clear();
    const v = raw.trim();
    setRecord(null); setResult(null); setTampered(false);
    if (!CODE_RE.test(v) && !HASH_RE.test(v)) {
      setPhase("error");
      setError("Format tidak valid. Gunakan kode seperti BT-001 atau hash SHA-256 (64 karakter hex).");
      return;
    }
    setPhase("scanning"); setScanIdx(0);
    timers.current.push(window.setTimeout(() => setScanIdx(1), 600), window.setTimeout(() => setScanIdx(2), 1200));
    timers.current.push(window.setTimeout(() => {
      const rec = findRecord(v);
      if (!rec) { setPhase("error"); setError("Tidak ada catatan on-chain untuk kode atau hash ini."); return; }
      setRecord(rec); setPhase("done");
      runVerify(rec, false, 0);
    }, 1800));
  }, [findRecord, runVerify]);

  useEffect(() => {
    if (q) { setInput(q); lookup(q); }
    return clear;
  }, [q, lookup]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() === q) lookup(input);
    else navigate({ to: "/verifikasi", search: { q: input.trim() } });
  };

  const entry = record ? lastEntry(record) : null;

  return (
    <PublicLayout>
      <div className="mx-auto max-w-3xl px-4 py-10">
        <h1 className="text-3xl font-bold">Verifikasi Penyaluran</h1>
        <p className="mt-1 text-sm text-muted-foreground">Cari dengan kode anonim atau hash dokumen. Data pribadi tidak pernah ditampilkan.</p>
        <form onSubmit={submit} className="mt-6 flex flex-col gap-2 sm:flex-row">
          <SearchInput value={input} onChange={setInput} placeholder="BT-001 atau hash SHA-256" className="flex-1" />
          <Button type="submit" loading={phase === "scanning"}>Cari</Button>
        </form>

        <div className="mt-6">
          {phase === "idle" && <Card className="text-center text-sm text-muted-foreground">Masukkan kode untuk memulai. Contoh: <span className="font-mono">BT-001</span></Card>}

          {phase === "scanning" && (
            <Card className="relative overflow-hidden">
              <div className="absolute inset-x-0 top-0 h-0.5 overflow-hidden bg-muted"><div className="scan-line h-full w-1/3 bg-gradient-primary" /></div>
              <div className="flex items-center gap-3">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <p className="font-mono text-sm">{SCAN_MSGS[scanIdx]}</p>
              </div>
              <div className="mt-4 space-y-2">
                {[0, 1, 2].map((i) => <div key={i} className="h-3 animate-pulse rounded bg-muted" style={{ width: `${90 - i * 20}%` }} />)}
              </div>
            </Card>
          )}

          {phase === "error" && <ErrorState title="Verifikasi tidak dapat dilakukan" desc={error} />}

          {phase === "done" && record && entry && (
            <div className="space-y-4">
              <Card className={cn("border-2", result ? (result.ok ? "border-success/50" : "border-danger/50") : "")}>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    {verifying || !result ? <Loader2 className="h-9 w-9 animate-spin text-primary" /> : result.ok ? <CheckCircle2 className="h-9 w-9 text-success" /> : <XCircle className="h-9 w-9 text-danger" />}
                    <div>
                      <p className="text-xs text-muted-foreground">Hasil verifikasi</p>
                      <p className={cn("font-display text-2xl font-bold", result?.ok ? "text-success" : result ? "text-danger" : "")}>
                        {verifying || !result ? "Memeriksa…" : result.ok ? "SESUAI" : "TIDAK SESUAI"}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-mono text-lg font-semibold">{record.code}</p>
                    <Badge status={currentStatus(record)} />
                  </div>
                </div>

                <div className="mt-5 grid gap-3 text-sm sm:grid-cols-2">
                  <Field icon={<Fingerprint className="h-3.5 w-3.5" />} label="Hash dokumen (on-chain)"><Mono>{record.onchainHash}</Mono></Field>
                  <Field icon={<Fingerprint className="h-3.5 w-3.5" />} label="Hash dihitung ulang (off-chain)">
                    {result ? <Mono className={result.ok ? "text-success" : "text-danger"}>{result.recomputed}</Mono> : "—"}
                  </Field>
                  <Field icon={<Blocks className="h-3.5 w-3.5" />} label="Nomor blok (simulasi)"><span className="font-mono">#{entry.block.toLocaleString("id-ID")}</span></Field>
                  <Field icon={<ShieldCheck className="h-3.5 w-3.5" />} label="Tx signature (simulasi)">
                    <span className="font-mono text-xs" title={entry.tx}>{shortAddr(entry.tx, 10)}</span>
                  </Field>
                </div>

                <div className="mt-5 flex flex-wrap items-center gap-2">
                  <Button onClick={() => runVerify(record, tampered)} loading={verifying}><ShieldCheck className="h-4 w-4" /> Verify Hash</Button>
                  <a href={explorerUrl(entry.tx)} target="_blank" rel="noopener noreferrer" className="inline-flex h-10 items-center gap-2 rounded-xl border bg-surface px-4 text-sm font-semibold hover:bg-accent">
                    View on Explorer <ExternalLink className="h-4 w-4" />
                  </a>
                </div>

                <label className="mt-4 flex cursor-pointer items-start gap-3 rounded-xl border border-dashed bg-surface p-3 text-sm">
                  <input
                    type="checkbox"
                    checked={tampered}
                    onChange={(e) => { setTampered(e.target.checked); runVerify(record, e.target.checked); }}
                    className="mt-0.5 h-4 w-4 accent-[var(--danger)]"
                  />
                  <span>
                    <span className="flex items-center gap-1 font-semibold"><ShieldAlert className="h-4 w-4 text-warning" /> Demo: Simulasikan catatan dipalsukan (ubah 1 karakter)</span>
                    <span className="text-xs text-muted-foreground">Mengubah satu karakter pada catatan off-chain sebelum di-hash ulang.</span>
                  </span>
                </label>
              </Card>

              <Card>
                <h2 className="mb-4 font-semibold">Riwayat status</h2>
                <StatusTimeline timeline={record.timeline} />
              </Card>
            </div>
          )}
        </div>
      </div>
    </PublicLayout>
  );
}

function Field({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0 rounded-xl bg-surface p-3">
      <p className="mb-1 flex items-center gap-1 text-xs text-muted-foreground">{icon} {label}</p>
      {children}
    </div>
  );
}
