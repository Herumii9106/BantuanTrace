import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, FileText, PenTool, ShieldAlert, UserRound } from "lucide-react";
import { toast } from "sonner";
import { DashboardShell, RoleGate } from "@/components/bt/Layout";
import { Badge, Button, Card, EmptyState, LoadingState, Modal, StatCard } from "@/components/bt/primitives";
import { QRProofCard } from "@/components/bt/QRProofCard";
import { StatusTimeline } from "@/components/bt/StatusTimeline";
import { type AidRecord, CURRENT_RECIPIENT, WALLETS, currentStatus, formatIDR, randomHex, shortAddr } from "@/lib/bt-data";
import { usePageLoad, useStore } from "@/lib/bt-store";

export const Route = createFileRoute("/penerima")({
  head: () => ({
    meta: [
      { title: "Bantuan Saya — BantuanTrace" },
      { name: "description", content: "Lihat status bantuan pendidikan Anda dan konfirmasi penerimaan." },
      { property: "og:title", content: "Bantuan Saya — BantuanTrace" },
      { property: "og:description", content: "Status bantuan dan bukti terima untuk penerima." },
    ],
  }),
  component: () => (
    <RoleGate role="penerima">
      <DashboardShell role="penerima" title="Bantuan Saya">
        <RecipientPage />
      </DashboardShell>
    </RoleGate>
  ),
});

function RecipientPage() {
  const { records } = useStore();
  const loading = usePageLoad();
  const [signing, setSigning] = useState<AidRecord | null>(null);
  const mine = useMemo(() => records.filter((r) => r.recipientCode === CURRENT_RECIPIENT.code), [records]);
  const received = mine.filter((r) => currentStatus(r) === "DITERIMA").length;

  return (
    <>
      <Card className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="flex flex-1 items-center gap-3">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground"><UserRound className="h-6 w-6" /></span>
          <div>
            <p className="font-semibold">{CURRENT_RECIPIENT.name}</p>
            <p className="font-mono text-xs text-muted-foreground">{CURRENT_RECIPIENT.code} · {shortAddr(WALLETS.penerima)}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:w-80">
          <StatCard label="Total Bantuan" value={mine.length} icon={<FileText className="h-4 w-4" />} tone="info" />
          <StatCard label="Dikonfirmasi" value={received} icon={<CheckCircle2 className="h-4 w-4" />} tone="success" />
        </div>
      </Card>

      {loading ? <LoadingState /> : mine.length === 0 ? <EmptyState title="Belum ada bantuan" desc="Catatan bantuan Anda akan muncul di sini." /> : (
        <div className="grid gap-4 lg:grid-cols-2">
          {mine.map((r) => {
            const s = currentStatus(r);
            return (
              <div key={r.code} className="space-y-4">
                <Card>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-mono text-xs text-muted-foreground">{r.code}</p>
                      <h3 className="mt-1 font-semibold">{r.program}</h3>
                      <p className="text-sm text-muted-foreground">{formatIDR(r.amount)}</p>
                    </div>
                    <Badge status={s} />
                  </div>
                  <div className="mt-4"><StatusTimeline timeline={r.timeline} compact /></div>
                  <div className="mt-4"><StatusTimeline timeline={r.timeline} /></div>
                  {s === "DICAIRKAN" && (
                    <Button className="mt-4 w-full" onClick={() => setSigning(r)}><PenTool className="h-4 w-4" /> Konfirmasi Terima</Button>
                  )}
                </Card>
                {s === "DITERIMA" && <QRProofCard record={r} />}
              </div>
            );
          })}
        </div>
      )}

      {signing && <SignModal record={signing} onClose={() => setSigning(null)} />}
    </>
  );
}

function SignModal({ record, onClose }: { record: AidRecord; onClose: () => void }) {
  const { updateStatus } = useStore();
  const [busy, setBusy] = useState(false);
  const [nonce] = useState(() => randomHex(8));
  const message = `BantuanTrace\nSaya mengonfirmasi telah menerima bantuan dengan kode ${record.code}.\nNonce: ${nonce}`;

  const sign = async () => {
    setBusy(true);
    try {
      await updateStatus(record.code, "DITERIMA");
      toast.success(`${record.code} dikonfirmasi DITERIMA`, { description: "Recorded to Solana devnet (simulated)" });
      onClose();
    } catch {
      toast.error("Tanda tangan gagal. Coba lagi.");
      setBusy(false);
    }
  };

  return (
    <Modal open onClose={onClose} title="Tanda Tangani Pesan" footer={<><Button variant="outline" onClick={onClose} disabled={busy}>Tolak</Button><Button onClick={sign} loading={busy}>Tanda Tangani</Button></>}>
      <p className="text-sm text-muted-foreground">Wallet <span className="font-mono">{shortAddr(WALLETS.penerima)}</span> diminta menandatangani pesan berikut:</p>
      <pre className="mt-3 whitespace-pre-wrap rounded-xl bg-surface p-3 font-mono text-xs">{message}</pre>
      <div className="mt-3 flex gap-2 rounded-xl border border-warning/40 bg-warning/10 p-3 text-xs">
        <ShieldAlert className="h-4 w-4 shrink-0 text-warning" />
        <p>Ini hanya tanda tangan pesan, <b>bukan transaksi</b>. Tidak ada biaya dan tidak ada dana yang berpindah. Kami tidak pernah meminta seed phrase, private key, atau kata sandi.</p>
      </div>
    </Modal>
  );
}
