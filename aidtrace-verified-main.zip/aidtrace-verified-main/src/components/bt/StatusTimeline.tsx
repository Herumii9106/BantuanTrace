import { Check, Circle, X } from "lucide-react";
import { type Status, type TimelineEntry, formatTs, shortAddr } from "@/lib/bt-data";
import { cn } from "@/lib/utils";

const FLOW: Status[] = ["DIAJUKAN", "DISETUJUI", "DICAIRKAN", "DITERIMA"];

export function StatusTimeline({ timeline, compact }: { timeline: TimelineEntry[]; compact?: boolean }) {
  const cancelled = timeline.find((t) => t.status === "DIBATALKAN");
  const steps: Status[] = cancelled ? [...timeline.map((t) => t.status)] : FLOW;

  if (compact) {
    return (
      <div className="flex items-center gap-1">
        {steps.map((s, i) => {
          const done = timeline.some((t) => t.status === s);
          return (
            <div key={s} className="flex flex-1 items-center gap-1">
              <span
                title={s}
                className={cn(
                  "h-2 w-full rounded-full",
                  !done && "bg-muted",
                  done && s === "DIBATALKAN" && "bg-danger",
                  done && s === "DITERIMA" && "bg-success",
                  done && s !== "DIBATALKAN" && s !== "DITERIMA" && "bg-primary",
                )}
              />
              {i < steps.length - 1 && null}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <ol className="relative space-y-4">
      {steps.map((s, i) => {
        const entry = timeline.find((t) => t.status === s);
        const isCancel = s === "DIBATALKAN";
        return (
          <li key={s} className="relative flex gap-3">
            {i < steps.length - 1 && <span className={cn("absolute left-[13px] top-7 h-[calc(100%-4px)] w-px", entry ? "bg-primary/50" : "bg-border")} />}
            <span
              className={cn(
                "z-10 flex h-7 w-7 shrink-0 items-center justify-center rounded-full ring-1 ring-inset",
                !entry && "bg-muted text-muted-foreground ring-border",
                entry && isCancel && "bg-danger/15 text-danger ring-danger/40",
                entry && s === "DITERIMA" && "bg-success/15 text-success ring-success/40",
                entry && !isCancel && s !== "DITERIMA" && "bg-primary/15 text-primary ring-primary/40",
              )}
            >
              {entry ? isCancel ? <X className="h-3.5 w-3.5" /> : <Check className="h-3.5 w-3.5" /> : <Circle className="h-2.5 w-2.5" />}
            </span>
            <div className="min-w-0 pb-1">
              <p className={cn("font-mono text-xs font-semibold", !entry && "text-muted-foreground")}>{s}</p>
              {entry ? (
                <p className="mt-0.5 text-xs text-muted-foreground">
                  {formatTs(entry.ts)} · <span className="font-mono">{shortAddr(entry.actor)}</span> · blok #{entry.block.toLocaleString("id-ID")}
                </p>
              ) : (
                <p className="mt-0.5 text-xs text-muted-foreground">Menunggu</p>
              )}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
