import { useEffect, type ReactNode } from "react";
import { AlertTriangle, Inbox, Loader2, Search, X } from "lucide-react";
import type { Status } from "@/lib/bt-data";
import { cn } from "@/lib/utils";

/* ---------- Badge ---------- */
const STATUS_STYLE: Record<Status, string> = {
  DIAJUKAN: "bg-info/15 text-info ring-info/30",
  DISETUJUI: "bg-warning/15 text-warning ring-warning/30",
  DICAIRKAN: "bg-warning/15 text-warning ring-warning/30",
  DITERIMA: "bg-success/15 text-success ring-success/30",
  DIBATALKAN: "bg-danger/15 text-danger ring-danger/30",
};

type Tone = "success" | "warning" | "danger" | "info" | "neutral";
const TONE: Record<Tone, string> = {
  success: "bg-success/15 text-success ring-success/30",
  warning: "bg-warning/15 text-warning ring-warning/30",
  danger: "bg-danger/15 text-danger ring-danger/30",
  info: "bg-info/15 text-info ring-info/30",
  neutral: "bg-muted text-muted-foreground ring-border",
};

export function Badge({ status, tone, children, className }: { status?: Status; tone?: Tone; children?: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 font-mono text-[11px] font-semibold tracking-wide ring-1 ring-inset",
        status ? STATUS_STYLE[status] : TONE[tone ?? "neutral"],
        className,
      )}
    >
      {children ?? status}
    </span>
  );
}

/* ---------- Card ---------- */
export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("rounded-2xl border bg-card p-5 text-card-foreground", className)}>{children}</div>;
}

/* ---------- Button ---------- */
type BtnVariant = "primary" | "outline" | "ghost" | "success" | "danger" | "warning";
const BTN: Record<BtnVariant, string> = {
  primary: "bg-gradient-primary text-primary-foreground shadow-elegant hover:opacity-90",
  outline: "border bg-surface text-foreground hover:bg-accent",
  ghost: "text-muted-foreground hover:bg-accent hover:text-foreground",
  success: "bg-success/15 text-success ring-1 ring-inset ring-success/30 hover:bg-success/25",
  danger: "bg-danger/15 text-danger ring-1 ring-inset ring-danger/30 hover:bg-danger/25",
  warning: "bg-warning/15 text-warning ring-1 ring-inset ring-warning/30 hover:bg-warning/25",
};
export function Button({
  variant = "primary",
  size = "md",
  className,
  loading,
  children,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant; size?: "sm" | "md"; loading?: boolean }) {
  return (
    <button
      {...props}
      disabled={props.disabled || loading}
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition disabled:cursor-not-allowed disabled:opacity-50",
        size === "sm" ? "h-8 px-3 text-xs" : "h-10 px-4 text-sm",
        BTN[variant],
        className,
      )}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
}

/* ---------- Modal ---------- */
export function Modal({ open, onClose, title, children, footer }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-background/80 p-0 backdrop-blur-sm sm:items-center sm:p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onClick={(e) => e.stopPropagation()}
        className="max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-t-2xl border bg-popover p-5 shadow-elegant sm:rounded-2xl"
      >
        <div className="mb-4 flex items-center justify-between gap-4">
          <h2 className="text-lg font-semibold">{title}</h2>
          <button onClick={onClose} aria-label="Tutup" className="rounded-lg p-1 text-muted-foreground hover:bg-accent">
            <X className="h-5 w-5" />
          </button>
        </div>
        {children}
        {footer && <div className="mt-5 flex flex-wrap justify-end gap-2">{footer}</div>}
      </div>
    </div>
  );
}

/* ---------- SearchInput ---------- */
export function SearchInput({ value, onChange, placeholder, className, maxLength = 80 }: { value: string; onChange: (v: string) => void; placeholder?: string; className?: string; maxLength?: number }) {
  return (
    <div className={cn("relative", className)}>
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <input
        value={value}
        maxLength={maxLength}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-10 w-full rounded-xl border bg-surface pl-9 pr-3 font-mono text-sm outline-none placeholder:font-sans placeholder:text-muted-foreground focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}

/* ---------- Table ---------- */
export interface Column<T> {
  header: string;
  cell: (row: T) => ReactNode;
  className?: string;
}
export function Table<T>({ columns, rows, rowKey, empty }: { columns: Column<T>[]; rows: T[]; rowKey: (r: T) => string; empty?: ReactNode }) {
  if (rows.length === 0) return <>{empty ?? <EmptyState title="Tidak ada data" />}</>;
  return (
    <div className="overflow-x-auto rounded-xl border">
      <table className="w-full min-w-[640px] text-sm">
        <thead className="bg-surface text-left text-xs uppercase tracking-wider text-muted-foreground">
          <tr>
            {columns.map((c) => (
              <th key={c.header} className={cn("px-4 py-3 font-semibold", c.className)}>
                {c.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y">
          {rows.map((r) => (
            <tr key={rowKey(r)} className="hover:bg-accent/40">
              {columns.map((c) => (
                <td key={c.header} className={cn("px-4 py-3 align-middle", c.className)}>
                  {c.cell(r)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ---------- States ---------- */
export function LoadingState({ label = "Memuat data…" }: { label?: string }) {
  return (
    <div className="space-y-3" aria-busy="true">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Loader2 className="h-4 w-4 animate-spin" /> {label}
      </div>
      {[0, 1, 2].map((i) => (
        <div key={i} className="h-16 animate-pulse rounded-xl bg-muted" />
      ))}
    </div>
  );
}
export function EmptyState({ title, desc }: { title: string; desc?: string }) {
  return (
    <div className="flex flex-col items-center rounded-xl border border-dashed p-10 text-center">
      <Inbox className="h-8 w-8 text-muted-foreground" />
      <p className="mt-3 font-semibold">{title}</p>
      {desc && <p className="mt-1 text-sm text-muted-foreground">{desc}</p>}
    </div>
  );
}
export function ErrorState({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center rounded-xl border border-danger/40 bg-danger/5 p-8 text-center">
      <AlertTriangle className="h-8 w-8 text-danger" />
      <p className="mt-3 font-semibold">{title}</p>
      {desc && <p className="mt-1 text-sm text-muted-foreground">{desc}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

/* ---------- StatCard ---------- */
export function StatCard({ label, value, icon, tone = "info" }: { label: string; value: ReactNode; icon: ReactNode; tone?: Tone }) {
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <span className={cn("rounded-lg p-1.5 ring-1 ring-inset", TONE[tone])}>{icon}</span>
      </div>
      <p className="mt-2 font-display text-2xl font-bold sm:text-3xl">{value}</p>
    </Card>
  );
}

export function Mono({ children, className }: { children: ReactNode; className?: string }) {
  return <span className={cn("break-all font-mono text-xs", className)}>{children}</span>;
}
