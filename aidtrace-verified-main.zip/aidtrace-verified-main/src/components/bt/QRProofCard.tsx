import { Link } from "@tanstack/react-router";
import { QRCodeSVG } from "qrcode.react";
import { Copy, Download, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { type AidRecord, lastEntry, formatTs } from "@/lib/bt-data";
import { Button, Card, Mono } from "./primitives";

export function QRProofCard({ record }: { record: AidRecord }) {
  const entry = lastEntry(record);
  const path = `/verifikasi?q=${encodeURIComponent(record.code)}`;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(window.location.origin + path);
      toast.success("Tautan verifikasi disalin");
    } catch {
      toast.error("Gagal menyalin tautan");
    }
  };

  const download = () => {
    // Only on-chain proof fields — no personal data.
    const proof = {
      aplikasi: "BantuanTrace (demo, Solana devnet simulasi)",
      kode: record.code,
      status: entry.status,
      hash: record.onchainHash,
      waktu: entry.ts,
      tx: entry.tx,
      blok: entry.block,
    };
    const url = URL.createObjectURL(new Blob([JSON.stringify(proof, null, 2)], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `bukti-terima-${record.code}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="border-success/40 bg-success/5">
      <div className="flex items-center gap-2 text-success">
        <ShieldCheck className="h-5 w-5" />
        <h3 className="font-semibold">Bukti Terima</h3>
      </div>
      <div className="mt-4 flex flex-col gap-4 sm:flex-row">
        <div className="self-center rounded-xl bg-foreground p-3 text-background">
          <QRCodeSVG value={`https://bantuantrace.app${path}`} size={120} bgColor="transparent" fgColor="currentColor" />
        </div>
        <dl className="min-w-0 flex-1 space-y-2 text-sm">
          <div><dt className="text-xs text-muted-foreground">Kode anonim</dt><dd className="font-mono font-semibold">{record.code}</dd></div>
          <div><dt className="text-xs text-muted-foreground">Hash</dt><dd><Mono>{record.onchainHash}</Mono></dd></div>
          <div><dt className="text-xs text-muted-foreground">Waktu</dt><dd>{formatTs(entry.ts)}</dd></div>
        </dl>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        <Button size="sm" variant="outline" onClick={copy}><Copy className="h-3.5 w-3.5" /> Salin Tautan Verifikasi</Button>
        <Link to="/verifikasi" search={{ q: record.code }} className="inline-flex h-8 items-center gap-2 rounded-xl bg-gradient-primary px-3 text-xs font-semibold text-primary-foreground">
          <ShieldCheck className="h-3.5 w-3.5" /> Verifikasi On-Chain
        </Link>
        <Button size="sm" variant="outline" onClick={download}><Download className="h-3.5 w-3.5" /> Download Bukti</Button>
      </div>
    </Card>
  );
}
