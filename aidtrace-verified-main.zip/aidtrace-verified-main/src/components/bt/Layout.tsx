import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ChevronsLeft, ChevronsRight, FileSearch, GraduationCap, LayoutDashboard, ListChecks, Lock, LogOut, ShieldCheck, Wallet } from "lucide-react";
import { type Role, ROLE_HOME, ROLE_LABEL, WALLETS, shortAddr } from "@/lib/bt-data";
import { useStore } from "@/lib/bt-store";
import { cn } from "@/lib/utils";
import { Button, Card, Modal } from "./primitives";

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold">
      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary text-primary-foreground">
        <ShieldCheck className="h-4.5 w-4.5" />
      </span>
      BantuanTrace
    </Link>
  );
}

export function ConnectWalletButton({ className }: { className?: string }) {
  const { role, wallet, connect, disconnect } = useStore();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  if (role && wallet) {
    return (
      <div className={cn("flex items-center gap-2", className)}>
        <span className="hidden rounded-xl border bg-surface px-3 py-2 font-mono text-xs sm:inline">
          {ROLE_LABEL[role]} · {shortAddr(wallet)}
        </span>
        <Button size="sm" variant="ghost" onClick={() => { disconnect(); navigate({ to: "/" }); }} aria-label="Putuskan wallet">
          <LogOut className="h-4 w-4" />
        </Button>
      </div>
    );
  }
  return (
    <>
      <Button size="sm" className={className} onClick={() => setOpen(true)}>
        <Wallet className="h-4 w-4" /> Connect Wallet
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title="Hubungkan Wallet (Simulasi)">
        <p className="text-sm text-muted-foreground">Pilih peran demo. Alamat wallet palsu, tidak ada integrasi wallet nyata. Kami tidak pernah meminta seed phrase, private key, atau kata sandi.</p>
        <div className="mt-4 space-y-2">
          {(Object.keys(WALLETS) as Role[]).map((r) => (
            <button
              key={r}
              onClick={() => { connect(r); setOpen(false); navigate({ to: ROLE_HOME[r] }); }}
              className="flex w-full items-center justify-between rounded-xl border bg-surface p-3 text-left hover:border-primary hover:bg-accent"
            >
              <span className="font-semibold">{ROLE_LABEL[r]}</span>
              <span className="font-mono text-xs text-muted-foreground">{shortAddr(WALLETS[r], 6)}</span>
            </button>
          ))}
        </div>
      </Modal>
    </>
  );
}

export function PublicLayout({ children }: { children: ReactNode }) {
  const { role } = useStore();
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4">
          <Logo />
          <nav className="flex items-center gap-1 text-sm">
            <Link to="/verifikasi" className="hidden rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground sm:inline" activeProps={{ className: "text-foreground" }}>Verifikasi</Link>
            {role && <Link to={ROLE_HOME[role]} className="rounded-lg px-3 py-2 text-muted-foreground hover:text-foreground">Dasbor</Link>}
            <ConnectWalletButton />
          </nav>
        </div>
      </header>
      <main>{children}</main>
      <footer className="border-t py-8 text-center text-xs text-muted-foreground">
        BantuanTrace — demo. Semua data fiktif. Solana devnet disimulasikan.
      </footer>
    </div>
  );
}

const NAV: Record<Role, { to: "/penyalur" | "/penerima" | "/auditor" | "/verifikasi"; label: string; icon: typeof LayoutDashboard }[]> = {
  penyalur: [
    { to: "/penyalur", label: "Dasbor", icon: LayoutDashboard },
    { to: "/verifikasi", label: "Verifikasi", icon: FileSearch },
  ],
  penerima: [
    { to: "/penerima", label: "Bantuan Saya", icon: GraduationCap },
    { to: "/verifikasi", label: "Verifikasi", icon: FileSearch },
  ],
  auditor: [
    { to: "/auditor", label: "Daftar Catatan", icon: ListChecks },
    { to: "/verifikasi", label: "Verifikasi", icon: FileSearch },
  ],
};

export function DashboardShell({ role, title, children }: { role: Role; title: string; children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const items = NAV[role];
  return (
    <div className="flex min-h-screen">
      <aside className={cn("sticky top-0 hidden h-screen shrink-0 flex-col border-r bg-surface p-3 transition-all md:flex", collapsed ? "w-16" : "w-60")}>
        <div className={cn("mb-6 flex h-10 items-center", collapsed ? "justify-center" : "px-2")}>
          {collapsed ? <ShieldCheck className="h-6 w-6 text-primary" /> : <Logo />}
        </div>
        <nav className="flex-1 space-y-1">
          {items.map((it) => (
            <Link
              key={it.to}
              to={it.to}
              title={it.label}
              className={cn("flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-foreground", collapsed && "justify-center")}
              activeProps={{ className: "bg-accent text-foreground" }}
            >
              <it.icon className="h-4 w-4 shrink-0" />
              {!collapsed && it.label}
            </Link>
          ))}
        </nav>
        <button onClick={() => setCollapsed((c) => !c)} className="flex items-center justify-center gap-2 rounded-xl p-2 text-xs text-muted-foreground hover:bg-accent" aria-label="Ciutkan sidebar">
          {collapsed ? <ChevronsRight className="h-4 w-4" /> : <><ChevronsLeft className="h-4 w-4" /> Ciutkan</>}
        </button>
      </aside>
      <div className="min-w-0 flex-1 pb-20 md:pb-0">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b bg-background/80 px-4 backdrop-blur sm:px-6">
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">{ROLE_LABEL[role]}</p>
            <h1 className="truncate text-lg font-semibold">{title}</h1>
          </div>
          <ConnectWalletButton />
        </header>
        <main className="space-y-6 p-4 sm:p-6">{children}</main>
      </div>
      <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t bg-surface/95 backdrop-blur md:hidden">
        {items.map((it) => (
          <Link key={it.to} to={it.to} className="flex flex-1 flex-col items-center gap-1 py-2.5 text-[11px] text-muted-foreground" activeProps={{ className: "text-primary" }}>
            <it.icon className="h-5 w-5" />
            {it.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}

export function RoleGate({ role, children }: { role: Role; children: ReactNode }) {
  const { role: current } = useStore();
  if (current === role) return <>{children}</>;
  return (
    <PublicLayout>
      <div className="mx-auto max-w-md px-4 py-20">
        <Card className="text-center">
          <Lock className="mx-auto h-8 w-8 text-warning" />
          <h1 className="mt-3 text-xl font-semibold">Akses dibatasi</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Halaman ini hanya untuk peran <b>{ROLE_LABEL[role]}</b>.{" "}
            {current ? `Anda terhubung sebagai ${ROLE_LABEL[current]}.` : "Hubungkan wallet terlebih dahulu."}
          </p>
          <div className="mt-5 flex justify-center">
            {current ? (
              <Link to={ROLE_HOME[current]} className="rounded-xl bg-gradient-primary px-4 py-2 text-sm font-semibold text-primary-foreground">Ke dasbor saya</Link>
            ) : (
              <ConnectWalletButton />
            )}
          </div>
        </Card>
      </div>
    </PublicLayout>
  );
}
