import { sha256 } from "js-sha256";

// All data here is fictional dummy data. Off-chain fields (alias, amount, document)
// are never rendered on public pages; only "on-chain" proof fields are.

export type Status = "DIAJUKAN" | "DISETUJUI" | "DICAIRKAN" | "DITERIMA" | "DIBATALKAN";
export type Role = "penyalur" | "penerima" | "auditor";

export const STATUSES: Status[] = ["DIAJUKAN", "DISETUJUI", "DICAIRKAN", "DITERIMA", "DIBATALKAN"];

export interface TimelineEntry {
  status: Status;
  ts: string;
  actor: string;
  tx: string;
  block: number;
}

export interface AidRecord {
  code: string;
  // off-chain
  alias: string;
  recipientCode: string;
  program: string;
  amount: number;
  docName: string;
  docHash: string;
  salt: string;
  // on-chain proof
  onchainHash: string;
  timeline: TimelineEntry[];
}

export const WALLETS: Record<Role, string> = {
  penyalur: "PNYL8k3vQx7fZ2mR9tLcW4hJ6bN1sDyE5aGuTo2KpXr",
  penerima: "RCPdM4sYq9wH2kVj7nLx3fB8cZ6tG1eRuA5oPiN2mQw",
  auditor: "AUDt6Gx2pK9wR4mJ7qLs3vN8cH1bZ5yEfT2uDoWiXk9",
};

export const ROLE_LABEL: Record<Role, string> = {
  penyalur: "Penyalur",
  penerima: "Penerima",
  auditor: "Auditor",
};

export const ROLE_HOME: Record<Role, "/penyalur" | "/penerima" | "/auditor"> = {
  penyalur: "/penyalur",
  penerima: "/penerima",
  auditor: "/auditor",
};

export const CURRENT_RECIPIENT = { name: "Dimas Prakoso (dummy)", code: "RCP-001" };

export const PROGRAMS: string[] = [
  "Bantuan Biaya Pendidikan Semester 1",
  "Bantuan Buku",
  "Bantuan Biaya Hidup",
  "Bantuan Biaya Pendidikan Semester 2",
  "Bantuan Transportasi Sekolah",
  "Bantuan Seragam",
];

const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";

export function fakeSig(seed: string): string {
  let out = "";
  let h = sha256(seed);
  while (out.length < 88) {
    for (let i = 0; i < h.length; i += 2) out += B58.charAt(parseInt(h.slice(i, i + 2), 16) % 58);
    h = sha256(h);
  }
  return out.slice(0, 88);
}

export function fakeBlock(seed: string): number {
  return 312_000_000 + (parseInt(sha256(seed).slice(0, 8), 16) % 9_000_000);
}

export function computeHash(r: Pick<AidRecord, "code" | "alias" | "recipientCode" | "program" | "amount" | "docName" | "docHash" | "salt">): string {
  return sha256([r.code, r.alias, r.recipientCode, r.program, r.amount, r.docName, r.docHash, r.salt].join("|"));
}

/** Demo helper: change exactly one character of an off-chain field. */
export function tamperRecord(r: AidRecord): AidRecord {
  const first = r.alias.charAt(0);
  return { ...r, alias: (first === "X" ? "Y" : "X") + r.alias.slice(1) };
}

export const currentStatus = (r: AidRecord): Status => r.timeline[r.timeline.length - 1]!.status;
export const lastEntry = (r: AidRecord) => r.timeline[r.timeline.length - 1]!;

export const shortAddr = (a: string, n = 4) => (a.length > n * 2 + 1 ? `${a.slice(0, n)}…${a.slice(-n)}` : a);

export const explorerUrl = (tx: string) => `https://explorer.solana.com/tx/${encodeURIComponent(tx)}?cluster=devnet`;

export function randomHex(bytes = 16): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

export function makeEntry(code: string, status: Status, ts: string, actor: string, nonce = ""): TimelineEntry {
  const seed = `${code}|${status}|${ts}|${nonce}`;
  return { status, ts, actor, tx: fakeSig(seed), block: fakeBlock(seed) };
}

export function nextAction(s: Status): Status[] {
  if (s === "DIAJUKAN") return ["DISETUJUI", "DIBATALKAN"];
  if (s === "DISETUJUI") return ["DICAIRKAN", "DIBATALKAN"];
  if (s === "DICAIRKAN") return ["DIBATALKAN"];
  return [];
}

export const pad3 = (n: number) => String(n).padStart(3, "0");

export function formatTs(ts: string) {
  return new Intl.DateTimeFormat("id-ID", {
    dateStyle: "medium",
    timeStyle: "short",
    timeZone: "Asia/Jakarta",
  }).format(new Date(ts));
}

export const formatIDR = (n: number) =>
  new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(n);

const FLOW: Status[] = ["DIAJUKAN", "DISETUJUI", "DICAIRKAN", "DITERIMA"];

export function seedRecords(): AidRecord[] {
  const list: AidRecord[] = [];
  const own = [
    { program: PROGRAMS[0], final: 3 },
    { program: PROGRAMS[1], final: 2 },
    { program: PROGRAMS[2], final: 1 },
  ];
  for (let i = 0; i < 24; i++) {
    const code = `BT-${pad3(i + 1)}`;
    const isOwn = i < 3;
    const final = isOwn ? own[i]!.final : i % 4;
    const cancelled = !isOwn && i % 7 === 5;
    const start = Date.UTC(2026, 2 + (i % 7), 3 + ((i * 3) % 20), 2, 0);
    const base = {
      code,
      alias: isOwn ? CURRENT_RECIPIENT.name : `Penerima Dummy ${i + 1}`,
      recipientCode: isOwn ? CURRENT_RECIPIENT.code : `RCP-${pad3(i + 1)}`,
      program: isOwn ? own[i]!.program : PROGRAMS[i % PROGRAMS.length]!,
      amount: 500_000 + ((i * 137_000) % 3_000_000),
      docName: `dokumen-${code}.pdf`,
      docHash: sha256(`doc|${code}`),
      salt: sha256(`salt|${code}`).slice(0, 32),
    };
    const timeline: TimelineEntry[] = [];
    for (let s = 0; s <= final; s++) {
      const ts = new Date(start + s * (2 * 86400000 + 3 * 3600000)).toISOString();
      const actor = FLOW[s]! === "DITERIMA" ? (isOwn ? WALLETS.penerima : fakeSig(`w|${code}`).slice(0, 44)) : WALLETS.penyalur;
      timeline.push(makeEntry(code, FLOW[s]!, ts, actor));
    }
    if (cancelled) {
      const ts = new Date(start + (final + 1) * 86400000).toISOString();
      timeline.push(makeEntry(code, "DIBATALKAN", ts, WALLETS.penyalur));
    }
    list.push({ ...base, onchainHash: computeHash(base), timeline });
  }
  return list;
}

export const CODE_RE = /^BT-\d{3,6}$/i;
export const HASH_RE = /^[a-f0-9]{64}$/i;
