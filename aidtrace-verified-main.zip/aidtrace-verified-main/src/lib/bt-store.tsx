import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  type AidRecord,
  type Role,
  type Status,
  WALLETS,
  computeHash,
  currentStatus,
  makeEntry,
  pad3,
  randomHex,
  seedRecords,
} from "./bt-data";

interface NewRecordInput {
  alias: string;
  recipientCode: string;
  program: string;
  amount: number;
  docName: string;
  docHash: string;
  salt: string;
}

interface StoreValue {
  records: AidRecord[];
  role: Role | null;
  wallet: string | null;
  connect: (r: Role) => void;
  disconnect: () => void;
  nextCode: () => string;
  createRecord: (input: NewRecordInput) => Promise<AidRecord>;
  updateStatus: (code: string, status: Status) => Promise<void>;
  findRecord: (query: string) => AidRecord | undefined;
}

const Ctx = createContext<StoreValue | null>(null);
const delay = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function StoreProvider({ children }: { children: ReactNode }) {
  const [records, setRecords] = useState<AidRecord[]>(() => seedRecords());
  const [role, setRole] = useState<Role | null>(null);

  useEffect(() => {
    const saved = window.sessionStorage.getItem("bt-role");
    if (saved === "penyalur" || saved === "penerima" || saved === "auditor") setRole(saved);
  }, []);

  const connect = useCallback((r: Role) => {
    setRole(r);
    window.sessionStorage.setItem("bt-role", r);
  }, []);
  const disconnect = useCallback(() => {
    setRole(null);
    window.sessionStorage.removeItem("bt-role");
  }, []);

  const nextCode = useCallback(() => {
    const max = records.reduce((m, r) => Math.max(m, parseInt(r.code.slice(3), 10) || 0), 0);
    return `BT-${pad3(max + 1)}`;
  }, [records]);

  const createRecord = useCallback(
    async (input: NewRecordInput) => {
      await delay(1100);
      const code = nextCode();
      const base = { code, ...input };
      const rec: AidRecord = {
        ...base,
        onchainHash: computeHash(base),
        timeline: [makeEntry(code, "DIAJUKAN", new Date().toISOString(), WALLETS.penyalur, randomHex(4))],
      };
      setRecords((prev) => [rec, ...prev]);
      return rec;
    },
    [nextCode],
  );

  const updateStatus = useCallback(async (code: string, status: Status) => {
    await delay(1100);
    setRecords((prev) =>
      prev.map((r) => {
        if (r.code !== code) return r;
        const cur = currentStatus(r);
        if (cur === "DITERIMA" || cur === "DIBATALKAN") return r;
        const actor = status === "DITERIMA" ? WALLETS.penerima : WALLETS.penyalur;
        return { ...r, timeline: [...r.timeline, makeEntry(code, status, new Date().toISOString(), actor, randomHex(4))] };
      }),
    );
  }, []);

  const findRecord = useCallback(
    (q: string) => {
      const v = q.trim();
      return records.find((r) => r.code.toUpperCase() === v.toUpperCase() || r.onchainHash === v.toLowerCase());
    },
    [records],
  );

  const value = useMemo(
    () => ({
      records,
      role,
      wallet: role ? WALLETS[role] : null,
      connect,
      disconnect,
      nextCode,
      createRecord,
      updateStatus,
      findRecord,
    }),
    [records, role, connect, disconnect, nextCode, createRecord, updateStatus, findRecord],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useStore must be used within StoreProvider");
  return v;
}

export function usePageLoad(ms = 500) {
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setLoading(false), ms);
    return () => clearTimeout(t);
  }, [ms]);
  return loading;
}
